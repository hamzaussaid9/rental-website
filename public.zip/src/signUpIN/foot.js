import React from 'react';
import './foot.css';

const Foot = () => {
    return (
        <>
         <div class="foot">
  <span><i class="far fa-copyright"></i> Copy Right Reserved 2021</span>
</div>   
        </>
    )
}

export default Foot;
