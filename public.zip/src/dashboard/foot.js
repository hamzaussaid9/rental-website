import React from 'react';
import './dashboard.css';
const Foot = () => {
    return (
        <>
          <div class="dash-footer-bar">
    
        <div class="copyright">
           <a> copyright</a>
        </div>
 
      </div>  
        </>
    )
}

export default Foot;
